#include <ArduinoJson.h>
#include <FirebaseESP32.h> // Ensure you install "Firebase ESP32 Client" by Mobizt in Arduino IDE
#include <WebServer.h>
#include <WiFi.h>

// ================= Configurations =================

// WiFi config
// "Wokwi-GUEST" is an open network provided by Wokwi for internet access
const char *ssid = "Wokwi-GUEST";
const char *password = "";

// Firebase config
#define FIREBASE_HOST "greengrid-hill-default-rtdb.firebaseio.com"
// Wait, the screenshot only shows the apiKey (AIzaSy...). The RTDB REST API on
// ESP32 sometimes uses the apiKey as the "Database Secret" in the old
// FirebaseESP32 library if auth isn't strict, or an actual database secret. I
// will use the apiKey for now as that's what's visible in the config block. If
// the DB rules require actual DB secret, we'll cross that bridge.
#define FIREBASE_AUTH "AIzaSyD2tjiyP4KgFh_ClonJMtLF8n_4Y9M_eT4"

FirebaseData firebaseData;
WebServer server(80);

// Hardware Pins Configuration
// Moisture Sensors (Analog pins on ESP32, e.g., GPIO36/VP)
#define SENSOR_ZONE_A 36
#define SENSOR_ZONE_B 39
#define SENSOR_ZONE_C 34
#define SENSOR_ZONE_D 35

// Pump Control Relays (Digital Outputs)
#define PUMP_1_RELAY 26
#define PUMP_2_RELAY 27

// Tank Level Sensors (Ultrasonic)
#define TANK_MAIN_TRIG 19
#define TANK_MAIN_ECHO 18
#define TANK_RESERVE_TRIG 5
#define TANK_RESERVE_ECHO 17

// Global State Variables
String pump1_mode = "auto";
String pump2_mode = "auto";
bool pump1_status = false;
bool pump2_status = false;

unsigned long lastCommandTime = 0;
unsigned long lastFirebaseUpdate = 0;

// ================= Setup =================

void setup() {
  Serial.begin(115200);

  // Initialize pump pins
  pinMode(PUMP_1_RELAY, OUTPUT);
  pinMode(PUMP_2_RELAY, OUTPUT);
  digitalWrite(PUMP_1_RELAY, LOW); // Assumes LOW is OFF
  digitalWrite(PUMP_2_RELAY, LOW);

  // Initialize tank sensor pins
  pinMode(TANK_MAIN_TRIG, OUTPUT);
  pinMode(TANK_MAIN_ECHO, INPUT);
  pinMode(TANK_RESERVE_TRIG, OUTPUT);
  pinMode(TANK_RESERVE_ECHO, INPUT);

  // Connect to WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }
  Serial.println("\nConnected to WiFi");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP()); // Use this IP in your Flutter app settings

  // Initialize Firebase
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  Firebase.reconnectWiFi(true);
  Serial.println("Firebase Initialized");

  // Setup Routing for HTTP API
  setupRouting();
  server.begin();
  Serial.println("HTTP Server started on port 80");
}

// ================= Main Loop =================

void loop() {
  // Handle incoming HTTP client requests
  server.handleClient();

  // Execute Auto-Mode logic here if needed (e.g. read moisture, trigger pump
  // intuitively) handleAutoMode();

  // Sync Data to Firebase every 5 seconds
  if (millis() - lastFirebaseUpdate > 5000) {
    updateFirebase();
    lastFirebaseUpdate = millis();
  }
}

// ================= HTTP API Routing & Handlers =================

void setupRouting() {
  // Routes defined in ESP32_API_DOCS.md
  server.on("/api/pump/control", HTTP_POST, handlePumpControl);
  server.on("/api/pump/mode", HTTP_POST, handlePumpMode);
  server.on("/api/emergency/stop", HTTP_POST, handleEmergencyStop);

  // You might need a more customized path parsing for /api/pump/status/{pumpId}
  // For simplicity, we can do:
  server.on("/api/pump/status/pump_1", HTTP_GET, []() {
    sendPumpStatus("pump_1", pump1_status, pump1_mode, "Zone A");
  });
  server.on("/api/pump/status/pump_2", HTTP_GET, []() {
    sendPumpStatus("pump_2", pump2_status, pump2_mode, "Zone B");
  });

  // Handle CORS and 404
  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
      server.send(204);
    } else {
      server.send(404, "application/json",
                  "{\"error\":\"Endpoint not found\"}");
    }
  });
}

void handlePumpControl() {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  // Debounce Protection: Ignore commands within 2 seconds
  if (millis() - lastCommandTime < 2000) {
    server.send(429, "application/json",
                "{\"success\":false,\"error\":\"Too many requests - safety "
                "debounce active\"}");
    return;
  }

  String body = server.arg("plain");
  DynamicJsonDocument doc(512);
  DeserializationError error = deserializeJson(doc, body);

  if (error) {
    server.send(400, "application/json",
                "{\"success\":false,\"error\":\"Invalid JSON payload\"}");
    return;
  }

  String pumpId = doc["pumpId"] | "";
  String action = doc["action"] | ""; // "on" or "off"

  if (pumpId == "pump_1") {
    // Only allow manual control if mode is "manual"
    // (Optional logic based on requirements)
    if (pump1_mode == "auto") {
      server.send(400, "application/json",
                  "{\"success\":false,\"error\":\"Pump 1 is in auto mode. "
                  "Switch to manual first.\"}");
      return;
    }
    pump1_status = (action == "on");
    digitalWrite(PUMP_1_RELAY, pump1_status ? HIGH : LOW);

  } else if (pumpId == "pump_2") {
    if (pump2_mode == "auto") {
      server.send(400, "application/json",
                  "{\"success\":false,\"error\":\"Pump 2 is in auto mode. "
                  "Switch to manual first.\"}");
      return;
    }
    pump2_status = (action == "on");
    digitalWrite(PUMP_2_RELAY, pump2_status ? HIGH : LOW);

  } else {
    server.send(404, "application/json",
                "{\"success\":false,\"error\":\"Pump not found\"}");
    return;
  }

  lastCommandTime = millis();

  String response = "{\"success\":true,\"pumpId\":\"" + pumpId +
                    "\",\"status\":\"" + action + "\"}";
  server.send(200, "application/json", response);
}

void handlePumpMode() {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  String body = server.arg("plain");
  DynamicJsonDocument doc(512);
  deserializeJson(doc, body);

  String pumpId = doc["pumpId"] | "";
  String mode = doc["mode"] | ""; // "auto" or "manual"

  if (pumpId == "pump_1") {
    pump1_mode = mode;
  } else if (pumpId == "pump_2") {
    pump2_mode = mode;
  } else {
    server.send(404, "application/json",
                "{\"success\":false,\"error\":\"Pump not found\"}");
    return;
  }

  String response = "{\"success\":true,\"pumpId\":\"" + pumpId +
                    "\",\"mode\":\"" + mode + "\"}";
  server.send(200, "application/json", response);
}

void sendPumpStatus(String pumpId, bool status, String mode, String zone) {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  DynamicJsonDocument doc(256);
  doc["pumpId"] = pumpId;
  doc["isActive"] = status;
  doc["controlMode"] = mode;
  doc["zone"] = zone;
  // Mock data for flow and pressure
  doc["flowRate"] = status ? 12.5 : 0.0;
  doc["pressure"] = status ? 45.5 : 0.0;

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

void handleEmergencyStop() {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  pump1_status = false;
  pump2_status = false;
  digitalWrite(PUMP_1_RELAY, LOW);
  digitalWrite(PUMP_2_RELAY, LOW);

  server.send(200, "application/json",
              "{\"success\":true,\"message\":\"All pumps "
              "stopped\",\"stoppedPumps\":[\"pump_1\",\"pump_2\"]}");
}

// ================= Sensors & Firebase Sync =================

float readMoisture(int pin) {
  int rawValue = analogRead(pin);
  // Example mapping: 4095 is dry in ESP32, 0 is wet. Adjust as per your sensor
  float moisturePercent = map(rawValue, 4095, 0, 0, 100);
  if (moisturePercent < 0)
    moisturePercent = 0;
  if (moisturePercent > 100)
    moisturePercent = 100;
  return moisturePercent;
}

void updateFirebase() {
  float moistureA = readMoisture(SENSOR_ZONE_A);

  // Push Sensor Data
  Firebase.setFloat(firebaseData, "/sensors/sensor_zone_a/moistureLevel",
                    moistureA);
  Firebase.setString(firebaseData, "/sensors/sensor_zone_a/status",
                     moistureA > 30 ? "Safe" : "Critical");
  Firebase.setString(firebaseData, "/sensors/sensor_zone_a/location", "Zone A");

  // Push Pump Status
  Firebase.setBool(firebaseData, "/pumps/pump_1/isActive", pump1_status);
  Firebase.setString(firebaseData, "/pumps/pump_1/controlMode", pump1_mode);

  Firebase.setBool(firebaseData, "/pumps/pump_2/isActive", pump2_status);
  Firebase.setString(firebaseData, "/pumps/pump_2/controlMode", pump2_mode);

  // (Optional) Include tank levels and other sensors here
}
